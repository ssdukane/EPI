//>>built
define("dojo/cldr/nls/en-au/currency",{"AUD_symbol":"$","USD_symbol":"US$"});